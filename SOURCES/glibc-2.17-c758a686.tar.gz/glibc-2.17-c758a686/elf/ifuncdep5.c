/* Test STT_GNU_IFUNC symbols without -fPIC.  */

#include "ifuncmod5.c"
