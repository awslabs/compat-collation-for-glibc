/* Test local STT_GNU_IFUNC symbols with -static:

   1. Direct function call.
   2. Function pointer.
 */

#include "ifuncmain7.c"
