extern void mod2 (void);

void
mod1 (void)
{
  mod2 ();
}
