#include <stdio.h>

int
foo (int x)
{
  puts ("foo");
  return x * 2;
}
