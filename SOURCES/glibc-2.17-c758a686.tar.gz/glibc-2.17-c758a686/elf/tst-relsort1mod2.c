#include <math.h>

int
foo (double d)
{
  return floor (d) != 0.0;
}
