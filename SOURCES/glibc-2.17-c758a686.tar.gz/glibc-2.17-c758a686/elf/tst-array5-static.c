#include "tst-array5.c"
