#include <tls.h>

int __thread tlsvar;
