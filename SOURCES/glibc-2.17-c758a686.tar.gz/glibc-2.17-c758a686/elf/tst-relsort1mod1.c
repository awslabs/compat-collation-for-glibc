extern int foo (double);

int
bar (void)
{
  return foo (1.2);
}
