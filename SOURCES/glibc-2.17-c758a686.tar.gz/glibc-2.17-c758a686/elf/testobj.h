extern int preload (int a);

extern int foo (int);

extern int obj1func1 (int);

extern int obj1func2 (int);

extern int obj2func1 (int);

extern int obj2func2 (int);

extern int obj3func1 (int);

extern int obj3func2 (int);

extern int obj4func1 (int);
			 
extern int obj4func2 (int);
			 
extern int obj5func1 (int);
			 
extern int obj5func2 (int);
			 
extern int obj6func1 (int);
			 
extern int obj6func2 (int);

