#include "tst-array1.c"
