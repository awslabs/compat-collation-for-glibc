// BZ 12510
template<typename T>
struct S
{
  static int i;
};

extern int in_lib (void);
