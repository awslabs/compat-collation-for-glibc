extern void *foop;

void **foopp = &foop;
