extern void mod3 (void);

void
mod2 (void)
{
  mod3 ();
}
