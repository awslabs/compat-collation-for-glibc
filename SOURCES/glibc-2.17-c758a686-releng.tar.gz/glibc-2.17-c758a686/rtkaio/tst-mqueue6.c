#include <rt/tst-mqueue6.c>
