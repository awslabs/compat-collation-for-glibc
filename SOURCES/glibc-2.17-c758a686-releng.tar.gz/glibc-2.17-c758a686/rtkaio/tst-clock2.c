#include <rt/tst-clock2.c>
