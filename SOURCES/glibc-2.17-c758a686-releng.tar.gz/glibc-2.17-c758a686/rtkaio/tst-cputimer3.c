#include <rt/tst-cputimer3.c>
