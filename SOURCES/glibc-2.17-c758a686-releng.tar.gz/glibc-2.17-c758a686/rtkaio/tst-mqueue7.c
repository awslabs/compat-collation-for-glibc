#include <rt/tst-mqueue7.c>
