#include <clock_gettime.c>
