#include <rt/tst-cpuclock2.c>
