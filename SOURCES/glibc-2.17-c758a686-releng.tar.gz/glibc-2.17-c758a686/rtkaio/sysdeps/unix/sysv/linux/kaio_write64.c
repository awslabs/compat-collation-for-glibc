#include <kaio_misc.h>
#include <aio_write64.c>
