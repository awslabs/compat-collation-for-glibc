#define aio_read64 __renamed_aio_read64
#include <kaio_misc.h>
#undef aio_read64
#include <aio_read.c>
