#include_next <tst-mqueue8x.c>
