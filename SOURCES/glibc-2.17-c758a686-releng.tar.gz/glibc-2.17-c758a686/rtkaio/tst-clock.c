#include <rt/tst-clock.c>
