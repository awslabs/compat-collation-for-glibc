#include <get_clockfreq.c>
