#include <rt/tst-cputimer1.c>
