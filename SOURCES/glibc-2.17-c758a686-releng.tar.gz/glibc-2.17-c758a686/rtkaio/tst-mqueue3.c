#include <rt/tst-mqueue3.c>
