#include <rt/tst-cpuclock1.c>
