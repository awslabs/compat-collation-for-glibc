#include <rt/tst-cputimer2.c>
